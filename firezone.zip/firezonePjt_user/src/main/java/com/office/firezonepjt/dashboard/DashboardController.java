package com.office.firezonepjt.dashboard;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Slf4j
@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    // 실시간 관제 화면
    @GetMapping("/monitoring")
    public String monitoring() {
        log.info("monitoring()");

        String nextPage = "dashboard/dashboard";

        return nextPage;
    }

    // 탐지 목록
    @GetMapping("/detection")
    public String detection() {
        log.info("detection()");

        String nextPage = "dashboard/detection";

        return nextPage;
    }

    // 탐지 목록 상세
    @GetMapping("/listDetail")
    public String listDetail() {
        log.info("listDetail()");

        String nextPage = "dashboard/list_detail";

        return nextPage;
    }



}
